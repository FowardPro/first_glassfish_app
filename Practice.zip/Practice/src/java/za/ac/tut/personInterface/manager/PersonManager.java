/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.personInterface.manager;

import za.ac.tut.entity.Person;
import za.ac.tut.personInterface.PersonInterface;

/**
 *
 * @author Student
 */
public class PersonManager implements PersonInterface <Person>{
    private String userNameV;
    private String passwordV;
    @Override
    public boolean validUser(Person p) {
     this.userNameV="Foward";
     this.passwordV="123";
     if(!(p.getName().equals(userNameV) && passwordV.equals(p.getPassword())))
     {
        return false;
     }
     else
     {
         return true;
     }
    }
    
}
